<?  
$query = mysqli_connect('localhost', 'Юзер', 'Пароль', 'Бд');
if (!$query) {exit('Error DataBase loading...');}
?>