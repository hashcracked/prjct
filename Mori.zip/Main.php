<?

include ("minilibrary.php");
include ("ConnectBD.php");


if ($text == '/start') #Старт
{
    $getuser = mysqli_query($query, "SELECT * FROM `school` WHERE `chat_id` = '$tgID'"); #Проверяем наличие пользователя в БД
    if (mysqli_num_rows($getuser) == 0)
    {
        mysqli_query($query, "INSERT INTO `school` (`chat_id`) VALUES ('$tgID')");
    }
    SendQuery('sendMessage', array(
        'chat_id' => $tgID,
        'text' => "👋🏻",
        'parse_mode' => 'html'
    ));

    $menu[] = ['text' => "Расписание", 'callback_data' => "/checktasks"];
    $menui = array_chunk($menu, 1);
    $menuinline = ['inline_keyboard' => $menui];
    SendQuery('sendMessage', array(
        'chat_id' => $tgID,
        'text' => "Привет, <b>@$username</b>!
Выбери действие:",
        'parse_mode' => 'html',
        'reply_markup' => json_encode($menuinline)
    ));
}


if ($callback == '/checktasks') #Расписание 
{

    $checktask = mysqli_query($query, "SELECT * FROM `main` WHERE `active` = '1'");
    if (mysqli_num_rows($checktask) == 0)
    {
        $menu[] = ['text' => "Задать расписание", 'callback_data' => "/addtasks"];
        $menui = array_chunk($menu, 1);
        $menuinline = ['inline_keyboard' => $menui];
        SendQuery('sendMessage', array(
            'chat_id' => $tgIDInline,
            'text' => "Расписание на сегодняшний день отсутствует.",
            'parse_mode' => 'html',
            'reply_markup' => json_encode($menuinline)
        ));
        return false;
    }
    $checktasks = mysqli_query($query, "SELECT * FROM `main` WHERE `active` = '1' ORDER BY `main`.`urok` ASC");
    while ($checktask = mysqli_fetch_assoc($checktasks))
    {
        $teacher = $checktask['teacher'];
        $tea = mysqli_query($query, "SELECT * FROM `teachers` WHERE `id` = '$teacher' ");
        while ($teach = mysqli_fetch_assoc($tea))
        {
            $teacher = $teach['teacher'];
        }
        $subject = $checktask['subject'];
        $sub = mysqli_query($query, "SELECT * FROM `subjects` WHERE `id` = '$subject' ");
        while ($subj = mysqli_fetch_assoc($sub))
        {
            $subject = $subj['subject'];
        }
        $cabinet = $checktask['cabinet'];
        $cab = mysqli_query($query, "SELECT * FROM `cabinets` WHERE `id` = '$cabinet' ");
        while ($cabi = mysqli_fetch_assoc($cab))
        {
            $cabinet = $cabi['cabinet'];
        }
        $urok = $checktask['urok'];
        $main .= '' . $urok . " Урок | " . $subject . " | " . $teacher . " | " . $cabinet . " Кабинет\n\n";
    }
    $menu[] = ['text' => "Добавить урок", 'callback_data' => "/addtasks"];
    $menu[] = ['text' => "Убрать урок", 'callback_data' => "/editTasks"];
    $menui = array_chunk($menu, 1);
    $menuinline = ['inline_keyboard' => $menui];

    SendQuery('editMessageText', array(
        'chat_id' => $tgIDInline,
        'message_id' => $msgIDInline,
        'text' => "<b>Расписание на сегодня:</b>
$main",
        'reply_markup' => json_encode($menuinline) ,
        'parse_mode' => 'html'
    ));

}


if ($callback == '/editTasks') #Убираем уроки
{
    $checktasks = mysqli_query($query, "SELECT * FROM `main` WHERE `active` = '1' ORDER BY `main`.`urok` ASC");
    while ($checktask = mysqli_fetch_assoc($checktasks))
    {
        $teacher = $checktask['teacher'];
        $tea = mysqli_query($query, "SELECT * FROM `teachers` WHERE `id` = '$teacher' ");
        while ($teach = mysqli_fetch_assoc($tea))
        {
            $teacher = $teach['teacher'];
        }
        $subject = $checktask['subject'];
        $sub = mysqli_query($query, "SELECT * FROM `subjects` WHERE `id` = '$subject' ");
        while ($subj = mysqli_fetch_assoc($sub))
        {
            $subject = $subj['subject'];
        }
        $cabinet = $checktask['cabinet'];
        $cab = mysqli_query($query, "SELECT * FROM `cabinets` WHERE `id` = '$cabinet' ");
        while ($cabi = mysqli_fetch_assoc($cab))
        {
            $cabinet = $cabi['cabinet'];
        }
        $urok = $checktask['urok'];
        $menu[] = ['text' => "$urok Урок | $subject", 'callback_data' => "/edds,$urok"];
    }

    $menui = array_chunk($menu, 1);
    $menuinline = ['inline_keyboard' => $menui];
    SendQuery('editMessageText', array(
        'chat_id' => $tgIDInline,
        'message_id' => $msgIDInline,
        'text' => "<b>Выбери урок, который нужно убрать с расписания</b>
",
        'reply_markup' => json_encode($menuinline) ,
        'parse_mode' => 'html'
    ));

}


if (in_array(mb_strtolower($trimCallback[0]) , ['бот', '/edds']))
{
    $callbackdata = substr_replace($callback, null, 0, 6);
    $checktasks = mysqli_query($query, "SELECT * FROM `main` WHERE `urok` = '$callbackdata' ");
    while ($checktask = mysqli_fetch_assoc($checktasks))
    {
        $teacher = $checktask['teacher'];
        $tea = mysqli_query($query, "SELECT * FROM `teachers` WHERE `id` = '$teacher' ");
        while ($teach = mysqli_fetch_assoc($tea))
        {
            $teacher = $teach['teacher'];
        }
        $subject = $checktask['subject'];
        $sub = mysqli_query($query, "SELECT * FROM `subjects` WHERE `id` = '$subject' ");
        while ($subj = mysqli_fetch_assoc($sub))
        {
            $subject = $subj['subject'];
        }
        $cabinet = $checktask['cabinet'];
        $cab = mysqli_query($query, "SELECT * FROM `cabinets` WHERE `id` = '$cabinet' ");
        while ($cabi = mysqli_fetch_assoc($cab))
        {
            $cabinet = $cabi['cabinet'];
            $tonnage = $cabi['tonnage'];
        }
        $urok = $checktask['urok'];
    }
    $menu[] = ['text' => "Убрать урок", 'callback_data' => "/eddsd,$urok"];
    $menui = array_chunk($menu, 1);
    $menuinline = ['inline_keyboard' => $menui];
    SendQuery('editMessageText', array(
        'chat_id' => $tgIDInline,
        'message_id' => $msgIDInline,
        'text' => "<b>Урок:</b> $urok
<b>Учитель:</b> $teacher
<b>Предмет:</b> $subject
<b>Кабинет:</b> $cabinet | <code>Вместительность ($tonnage чел.)</code>",
        'reply_markup' => json_encode($menuinline) ,
        'parse_mode' => 'html'
    ));

}


if (in_array(mb_strtolower($trimCallback[0]) , ['бот', '/eddsd']))
{
    $callbackdata = substr_replace($callback, null, 0, 7);
    mysqli_query($query, "UPDATE `main` SET `active` = '3' WHERE `urok` = '$callbackdata'");
    $menu[] = ['text' => "Расписание на сегодня", 'callback_data' => "/checktasks"];
    $menui = array_chunk($menu, 1);
    $menuinline = ['inline_keyboard' => $menui];
    SendQuery('editMessageText', array(
        'chat_id' => $tgIDInline,
        'message_id' => $msgIDInline,
        'text' => "Готово!",
        'reply_markup' => json_encode($menuinline) ,
        'parse_mode' => 'html'
    ));
}


if ($callback == '/addtasks') #Добавляем урок
{

    $checktask = mysqli_query($query, "SELECT * FROM `main` WHERE `active` = '1'");
    if (mysqli_num_rows($checktask) == 5)
    {
        SendQuery('editMessageText', array(
            'chat_id' => $tgIDInline,
            'message_id' => $msgIDInline,
            'text' => "Активных уроков может быть только 5....
Уберите 1 из расписания и попробуйте заново.",
            'parse_mode' => 'html'
        ));
        return false;
    }
    $checktask = mysqli_query($query, "SELECT * FROM `subjects`");
    while ($subjects = mysqli_fetch_assoc($checktask))
    {
        $subject = $subjects['subject'];
        $subjectID = $subjects['id'];
        $menu[] = ['text' => "$subject", 'callback_data' => "/adds,$subjectID"];
    }

    $menui = array_chunk($menu, 1);
    $menuinline = ['inline_keyboard' => $menui];
    SendQuery('editMessageText', array(
        'chat_id' => $tgIDInline,
        'message_id' => $msgIDInline,
        'text' => "Выберите предмет:",
        'parse_mode' => 'html',
        'reply_markup' => json_encode($menuinline)
    ));
    mysqli_query($query, "UPDATE `school` SET `operation` = '1' WHERE `chat_id` = '$tgIDInline' ");
    return false;
}


if (in_array(mb_strtolower($trimCallback[0]) , ['бот', '/adds']))
{
    $callbackdata = substr_replace($callback, null, 0, 6);

    $checkops = mysqli_query($query, "SELECT * FROM `school` WHERE `chat_id` = '$tgIDInline'");
    while ($op = mysqli_fetch_assoc($checkops))
    {
        $checkop = $op['operation'];
    }

    if ($checkop == 1)
    {
        mysqli_query($query, "INSERT INTO `main` (`subject`,`teacher`) VALUES ('$callbackdata','00')");
        $checktask = mysqli_query($query, "SELECT * FROM `teachers`");
        while ($teachers = mysqli_fetch_assoc($checktask))
        {
            $teacher = $teachers['teacher'];
            $teacherID = $teachers['id'];
            $menu[] = ['text' => "$teacher", 'callback_data' => "/adds,$teacherID"];
        }

        $menui = array_chunk($menu, 1);
        $menuinline = ['inline_keyboard' => $menui];
        SendQuery('editMessageText', array(
            'chat_id' => $tgIDInline,
            'message_id' => $msgIDInline,
            'text' => "Выберите преподавателя к предмету:",
            'parse_mode' => 'html',
            'reply_markup' => json_encode($menuinline)
        ));
        mysqli_query($query, "UPDATE `school` SET `operation` = '2' WHERE `chat_id` = '$tgIDInline' ");
        return false;
    }

    if ($checkop == 2)
    {
        mysqli_query($query, "UPDATE `main` SET `cabinet` = '00' WHERE `teacher` = '00'");
        mysqli_query($query, "UPDATE `main` SET `teacher` = '$callbackdata' WHERE `teacher` = '00'");
        SendQuery('editMessageText', array(
            'chat_id' => $tgIDInline,
            'message_id' => $msgIDInline,
            'text' => "Напишите кабинет (от 1 до 150):",
            'parse_mode' => 'html'
        ));

        mysqli_query($query, "UPDATE `school` SET `operation` = '3' WHERE `chat_id` = '$tgIDInline' ");
        return false;
    }

}


$checkopp = mysqli_query($query, "SELECT * FROM `school` WHERE `chat_id` = '$tgID' AND `operation` = '4'");
if (mysqli_num_rows($checkopp) == 1)
{
    if ($text)
    {

        $cleanText = mysqli_real_escape_string($query, $text);

        $checkcab = mysqli_query($query, "SELECT * FROM `main` WHERE `urok` = '$cleanText' and `active` = '1'");
        if (mysqli_num_rows($checkcab) == 1)
        {
            SendQuery('sendMessage', array(
                'chat_id' => $tgID,
                'text' => "Такой урок уже есть.",
                'parse_mode' => 'html'
            ));
            return false;
        }
        mysqli_query($query, "UPDATE `main` SET `urok` = '$cleanText' WHERE `active` = '0'");
        mysqli_query($query, "UPDATE `main` SET `active` = '1' WHERE `active` = '0'");
        $menu[] = ['text' => "Добавить урок", 'callback_data' => "/addtasks"];
        $menui = array_chunk($menu, 1);
        $menuinline = ['inline_keyboard' => $menui];
        SendQuery('sendMessage', array(
            'chat_id' => $tgID,
            'text' => "Урок успешно добавлен!",
            'reply_markup' => json_encode($menuinline) ,
            'parse_mode' => 'html'
        ));
        mysqli_query($query, "UPDATE `school` SET `operation` = '0' WHERE `chat_id` = '$tgID' ");

        return false;
    }
}


$checkopp = mysqli_query($query, "SELECT * FROM `school` WHERE `chat_id` = '$tgID' AND `operation` = '3'");
if (mysqli_num_rows($checkopp) == 1)
{
    if ($text)
    {

        $cleanText = mysqli_real_escape_string($query, $text);

        $checkcab = mysqli_query($query, "SELECT * FROM `cabinets` WHERE `cabinet` = '$cleanText'");
        if (mysqli_num_rows($checkcab) == 0)
        {
            SendQuery('sendMessage', array(
                'chat_id' => $tgID,
                'text' => "Такого кабинета не найдено...",
                'parse_mode' => 'html'
            ));
            return false;
        }

        mysqli_query($query, "UPDATE `main` SET `cabinet` = '$cleanText' WHERE `cabinet` = '0'");
        $cabque = mysqli_query($query, "SELECT * FROM `cabinets` where `cabinet` = '$cleanText' ");
        while ($cab = mysqli_fetch_assoc($cabque))
        {
            $cabrows = $cab['tonnage'];
        }
        SendQuery('sendMessage', array(
            'chat_id' => $tgID,
            'text' => "
<b>Вместительность кабинета:</b> <code>$cabrows чел. </code>

Выберите каким по числу уроком он будет проходить
Введите значение от 1 до 5:",
            'parse_mode' => 'html'
        ));
        mysqli_query($query, "UPDATE `school` SET `operation` = '4' WHERE `chat_id` = '$tgID' ");

        return false;
    }
}

?>
