-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Янв 17 2024 г., 00:56
-- Версия сервера: 8.0.35-0ubuntu0.22.04.1
-- Версия PHP: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `bdbd`
--

-- --------------------------------------------------------

--
-- Структура таблицы `cabinets`
--

CREATE TABLE `cabinets` (
  `id` int NOT NULL,
  `cabinet` int NOT NULL,
  `tonnage` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `cabinets`
--

INSERT INTO `cabinets` (`id`, `cabinet`, `tonnage`) VALUES
(1, 1, 21),
(2, 2, 24),
(3, 3, 13),
(4, 4, 29),
(5, 5, 24),
(6, 6, 22),
(7, 7, 18),
(8, 8, 22),
(9, 9, 12),
(10, 10, 28),
(11, 11, 24),
(12, 12, 17),
(13, 13, 17),
(14, 14, 14),
(15, 15, 15),
(16, 16, 10),
(17, 17, 12),
(18, 18, 26),
(19, 19, 23),
(20, 20, 24),
(21, 21, 28),
(22, 22, 15),
(23, 23, 15),
(24, 24, 12),
(25, 25, 22),
(26, 26, 28),
(27, 27, 15),
(28, 28, 30),
(29, 29, 30),
(30, 30, 24),
(31, 31, 29),
(32, 32, 25),
(33, 33, 28),
(34, 34, 13),
(35, 35, 24),
(36, 36, 17),
(37, 37, 23),
(38, 38, 18),
(39, 39, 26),
(40, 40, 23),
(41, 41, 25),
(42, 42, 10),
(43, 43, 30),
(44, 44, 25),
(45, 45, 26),
(46, 46, 12),
(47, 47, 18),
(48, 48, 25),
(49, 49, 26),
(50, 50, 29),
(51, 51, 27),
(52, 52, 30),
(53, 53, 11),
(54, 54, 30),
(55, 55, 12),
(56, 56, 13),
(57, 57, 23),
(58, 58, 30),
(59, 59, 12),
(60, 60, 20),
(61, 61, 24),
(62, 62, 26),
(63, 63, 28),
(64, 64, 12),
(65, 65, 26),
(66, 66, 16),
(67, 67, 14),
(68, 68, 28),
(69, 69, 28),
(70, 70, 22),
(71, 71, 23),
(72, 72, 15),
(73, 73, 30),
(74, 74, 20),
(75, 75, 26),
(76, 76, 23),
(77, 77, 17),
(78, 78, 13),
(79, 79, 20),
(80, 80, 26),
(81, 81, 22),
(82, 82, 28),
(83, 83, 21),
(84, 84, 11),
(85, 85, 14),
(86, 86, 15),
(87, 87, 16),
(88, 88, 23),
(89, 89, 15),
(90, 90, 26),
(91, 91, 19),
(92, 92, 16),
(93, 93, 22),
(94, 94, 17),
(95, 95, 14),
(96, 96, 26),
(97, 97, 28),
(98, 98, 17),
(99, 99, 10),
(100, 100, 25),
(101, 101, 22),
(102, 102, 16),
(103, 103, 23),
(104, 104, 21),
(105, 105, 21),
(106, 106, 29),
(107, 107, 24),
(108, 108, 28),
(109, 109, 28),
(110, 110, 22),
(111, 111, 17),
(112, 112, 10),
(113, 113, 30),
(114, 114, 17),
(115, 115, 15),
(116, 116, 21),
(117, 117, 21),
(118, 118, 23),
(119, 119, 30),
(120, 120, 18),
(121, 121, 29),
(122, 122, 12),
(123, 123, 26),
(124, 124, 13),
(125, 125, 12),
(126, 126, 26),
(127, 127, 26),
(128, 128, 25),
(129, 129, 18),
(130, 130, 28),
(131, 131, 24),
(132, 132, 30),
(133, 133, 11),
(134, 134, 16),
(135, 135, 18),
(136, 136, 14),
(137, 137, 10),
(138, 138, 14),
(139, 139, 29),
(140, 140, 26),
(141, 141, 26),
(142, 142, 27),
(143, 143, 14),
(144, 144, 28),
(145, 145, 25),
(146, 146, 14),
(147, 147, 26),
(148, 148, 27),
(149, 149, 16),
(150, 150, 30);

-- --------------------------------------------------------

--
-- Структура таблицы `main`
--

CREATE TABLE `main` (
  `id` int NOT NULL,
  `cabinet` bigint NOT NULL,
  `teacher` int NOT NULL,
  `subject` int NOT NULL,
  `active` int NOT NULL,
  `urok` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Структура таблицы `school`
--

CREATE TABLE `school` (
  `id` int NOT NULL,
  `chat_id` bigint NOT NULL,
  `operation` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Структура таблицы `subjects`
--

CREATE TABLE `subjects` (
  `id` int NOT NULL,
  `subject` varchar(111) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `subjects`
--

INSERT INTO `subjects` (`id`, `subject`) VALUES
(1, 'Русский'),
(2, 'Математика'),
(3, 'Информатика'),
(4, 'Английский'),
(5, 'Алгебра');

-- --------------------------------------------------------

--
-- Структура таблицы `teachers`
--

CREATE TABLE `teachers` (
  `id` int NOT NULL,
  `teacher` varchar(111) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `teachers`
--

INSERT INTO `teachers` (`id`, `teacher`) VALUES
(1, 'Учитель Русского'),
(2, 'Учитель Математики'),
(3, 'Учитель Информатики'),
(4, 'Учитель Английского'),
(5, 'Учитель Алгебры');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `cabinets`
--
ALTER TABLE `cabinets`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `main`
--
ALTER TABLE `main`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `school`
--
ALTER TABLE `school`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `cabinets`
--
ALTER TABLE `cabinets`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=151;

--
-- AUTO_INCREMENT для таблицы `main`
--
ALTER TABLE `main`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT для таблицы `school`
--
ALTER TABLE `school`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `teachers`
--
ALTER TABLE `teachers`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
